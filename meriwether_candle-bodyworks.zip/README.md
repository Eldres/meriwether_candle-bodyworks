# meriwether_candle-bodyworks

This website was created for Kathie Sammons to be used for her home business of selling candles and bodywork products.

## URL

https://d2j944uc30a2px.cloudfront.net/ - *temporary webpath until a domain is purchased*

## Authors

* **Josh Nagel** - *Initial work* - [Eldres](https://github.com/Eldres)

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details
